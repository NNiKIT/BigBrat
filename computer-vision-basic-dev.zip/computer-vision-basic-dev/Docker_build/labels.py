lbl = {0: 'free space',
 1: 'the place is occupied'}